function _0x3252(_0x3e7fff, _0x1e0c5e) {
  const _0x55baf1 = _0x55ba();
  return (
    (_0x3252 = function (_0x3252c8, _0x394a9e) {
      _0x3252c8 = _0x3252c8 - 0x1c1;
      let _0x2b3518 = _0x55baf1[_0x3252c8];
      return _0x2b3518;
    }),
    _0x3252(_0x3e7fff, _0x1e0c5e)
  );
}
const _0x165772 = _0x3252;
(function (_0x39ee75, _0x445be6) {
  const _0x32ae5d = _0x3252,
    _0x5600bc = _0x39ee75();
  while (!![]) {
    try {
      const _0x27e653 =
        parseInt(_0x32ae5d(0x1d3)) / 0x1 +
        parseInt(_0x32ae5d(0x1cd)) / 0x2 +
        parseInt(_0x32ae5d(0x1d0)) / 0x3 +
        parseInt(_0x32ae5d(0x1d6)) / 0x4 +
        -parseInt(_0x32ae5d(0x1ca)) / 0x5 +
        parseInt(_0x32ae5d(0x1c6)) / 0x6 +
        -parseInt(_0x32ae5d(0x1c8)) / 0x7;
      if (_0x27e653 === _0x445be6) break;
      else _0x5600bc["push"](_0x5600bc["shift"]());
    } catch (_0x259bff) {
      _0x5600bc["push"](_0x5600bc["shift"]());
    }
  }
})(_0x55ba, 0x47ef1);
const express = require(_0x165772(0x1d2)),
  router = express[_0x165772(0x1c7)](),
  authController = require(_0x165772(0x1c3));
router[_0x165772(0x1c9)](_0x165772(0x1d7), authController[_0x165772(0x1c1)]),
  router["post"](_0x165772(0x1c4), authController["login"]),
  router[_0x165772(0x1c9)](_0x165772(0x1d4), authController["forgotPassword"]),
  router[_0x165772(0x1da)](_0x165772(0x1dc), authController[_0x165772(0x1cf)]),
  router["route"](_0x165772(0x1d1))[_0x165772(0x1dd)](
    authController[_0x165772(0x1de)]
  ),
  router["route"]("/me")[_0x165772(0x1dd)](
    authController[_0x165772(0x1d8)],
    authController[_0x165772(0x1cb)]
  ),
  router["route"](_0x165772(0x1cc))[_0x165772(0x1db)](
    authController[_0x165772(0x1d8)],
    authController[_0x165772(0x1c5)]
  ),
  router[_0x165772(0x1d9)](_0x165772(0x1ce))[_0x165772(0x1db)](
    authController[_0x165772(0x1d8)],
    authController[_0x165772(0x1c2)]
  ),
  (module[_0x165772(0x1d5)] = router);
function _0x55ba() {
  const _0x55501a = [
    "/logout",
    "express",
    "253017wDDhLC",
    "/forgetPassword",
    "exports",
    "2332972bzhpXW",
    "/signup",
    "protect",
    "route",
    "patch",
    "put",
    "/resetPassword/:token",
    "get",
    "logout",
    "signup",
    "updateProfile",
    "../controllers/authController",
    "/login",
    "updatePassword",
    "1231602xhHHlt",
    "Router",
    "9490159Mvfvuc",
    "post",
    "2207820mLKHei",
    "getUserProfile",
    "/password/update",
    "1094418SecCBs",
    "/me/update",
    "resetPassword",
    "1509618ECSzLC",
  ];
  _0x55ba = function () {
    return _0x55501a;
  };
  return _0x55ba();
}
