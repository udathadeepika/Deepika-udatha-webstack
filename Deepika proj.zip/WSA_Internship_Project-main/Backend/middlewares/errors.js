function _0x2d8b(_0x46cc36, _0x2ecaec) {
  const _0x5b9ddb = _0x5b9d();
  return (
    (_0x2d8b = function (_0x2d8b19, _0x21b67a) {
      _0x2d8b19 = _0x2d8b19 - 0x197;
      let _0x1f1b3f = _0x5b9ddb[_0x2d8b19];
      return _0x1f1b3f;
    }),
    _0x2d8b(_0x46cc36, _0x2ecaec)
  );
}
const _0x3fafe4 = _0x2d8b;
(function (_0x4e55bd, _0x181302) {
  const _0x7a28c4 = _0x2d8b,
    _0x1e42e3 = _0x4e55bd();
  while (!![]) {
    try {
      const _0x3f8e26 =
        -parseInt(_0x7a28c4(0x19c)) / 0x1 +
        parseInt(_0x7a28c4(0x197)) / 0x2 +
        parseInt(_0x7a28c4(0x199)) / 0x3 +
        -parseInt(_0x7a28c4(0x1a2)) / 0x4 +
        parseInt(_0x7a28c4(0x19a)) / 0x5 +
        parseInt(_0x7a28c4(0x1b4)) / 0x6 +
        (parseInt(_0x7a28c4(0x19e)) / 0x7) *
          (-parseInt(_0x7a28c4(0x1aa)) / 0x8);
      if (_0x3f8e26 === _0x181302) break;
      else _0x1e42e3["push"](_0x1e42e3["shift"]());
    } catch (_0x414793) {
      _0x1e42e3["push"](_0x1e42e3["shift"]());
    }
  }
})(_0x5b9d, 0xef413);
const ErrorHandler = require(_0x3fafe4(0x1a9));
module["exports"] = (_0x2cbcc5, _0xdadd2d, _0x4650b2, _0x2d2160) => {
  const _0xd9933b = _0x3fafe4;
  _0x2cbcc5[_0xd9933b(0x19b)] = _0x2cbcc5[_0xd9933b(0x19b)] || 0x1f4;
  process["env"][_0xd9933b(0x198)] === _0xd9933b(0x1b3) &&
    _0x4650b2[_0xd9933b(0x1ad)](_0x2cbcc5[_0xd9933b(0x19b)])[_0xd9933b(0x1ac)]({
      success: ![],
      error: _0x2cbcc5,
      errMessage: _0x2cbcc5["message"],
      stack: _0x2cbcc5["stack"],
    });
  if (process[_0xd9933b(0x1b2)][_0xd9933b(0x198)] === "PRODUCTION") {
    let _0x43cc3c = { ..._0x2cbcc5 };
    _0x43cc3c[_0xd9933b(0x1ae)] = _0x2cbcc5["message"];
    if (_0x2cbcc5[_0xd9933b(0x1a3)] == _0xd9933b(0x1ab)) {
      const _0x2828ec = _0xd9933b(0x1a7) + _0x2cbcc5["path"];
      _0x43cc3c = new ErrorHandler(_0x2828ec, 0x190);
    }
    if (_0x2cbcc5["name"] === _0xd9933b(0x19d)) {
      const _0x203968 = Object[_0xd9933b(0x1a0)](_0x2cbcc5[_0xd9933b(0x1a6)])[
        _0xd9933b(0x1a4)
      ]((_0x369124) => _0x369124[_0xd9933b(0x1ae)]);
      _0x43cc3c = new ErrorHandler(_0x203968, 0x190);
    }
    if (_0x2cbcc5[_0xd9933b(0x1a5)] === 0x2af8) {
      const _0x493272 =
        "Duplicate\x20" +
        Object[_0xd9933b(0x1a8)](_0x2cbcc5[_0xd9933b(0x1a1)]) +
        "\x20entered";
      _0x43cc3c = new ErrorHandler(_0x493272, 0x190);
    }
    if (_0x2cbcc5["name"] === _0xd9933b(0x1b1)) {
      const _0x3d05cf =
        "JSON\x20Web\x20Token\x20is\x20invalid.\x20Try\x20Again!!!";
      _0x43cc3c = new ErrorHandler(_0x3d05cf, 0x190);
    }
    if (_0x2cbcc5[_0xd9933b(0x1a3)] === _0xd9933b(0x1af)) {
      const _0xfd497d = _0xd9933b(0x19f);
      _0x43cc3c = new ErrorHandler(_0xfd497d, 0x190);
    }
    _0x4650b2[_0xd9933b(0x1ad)](_0x43cc3c[_0xd9933b(0x19b)])[_0xd9933b(0x1ac)]({
      success: ![],
      message: _0x43cc3c[_0xd9933b(0x1ae)] || _0xd9933b(0x1b0),
    });
  }
};
function _0x5b9d() {
  const _0x17c76b = [
    "json",
    "status",
    "message",
    "TokenExpiredError",
    "Internal\x20Server\x20Error",
    "JsonWebTokenError",
    "env",
    "DEVELOPMENT",
    "9239934yemJCW",
    "20850gufiZu",
    "NODE_ENV",
    "2849019JvFhHn",
    "4833640wqHSwI",
    "statusCode",
    "774153MfZvnv",
    "ValidationError",
    "13118jXJNqA",
    "JSON\x20Web\x20Token\x20is\x20expired.\x20Try\x20Again!!!",
    "values",
    "keyValue",
    "6003652ldAVnW",
    "name",
    "map",
    "code",
    "errors",
    "Resource\x20not\x20found.\x20Invalid:\x20",
    "keys",
    "../utils/errorHandler",
    "904xusvDR",
    "castError",
  ];
  _0x5b9d = function () {
    return _0x17c76b;
  };
  return _0x5b9d();
}
