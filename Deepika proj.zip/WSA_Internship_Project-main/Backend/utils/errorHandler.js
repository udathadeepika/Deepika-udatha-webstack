function _0x4ea7(_0x109ce7, _0x384ce3) {
  var _0x5af257 = _0x5af2();
  return (
    (_0x4ea7 = function (_0x4ea7af, _0x44ad52) {
      _0x4ea7af = _0x4ea7af - 0xc0;
      var _0x49526a = _0x5af257[_0x4ea7af];
      return _0x49526a;
    }),
    _0x4ea7(_0x109ce7, _0x384ce3)
  );
}
var _0x57d100 = _0x4ea7;
function _0x5af2() {
  var _0x26f0ed = [
    "42sFAYRX",
    "6erxXvi",
    "9mbtasK",
    "5041345DsKICJ",
    "176452uSzjOp",
    "exports",
    "928726xBKVQz",
    "1566770hwXvfR",
    "839992kJNYwF",
    "statusCode",
    "2974448nfJMJf",
    "933621mVFTPr",
  ];
  _0x5af2 = function () {
    return _0x26f0ed;
  };
  return _0x5af2();
}
(function (_0x1dc200, _0x514b6d) {
  var _0x33be65 = _0x4ea7,
    _0x2b409b = _0x1dc200();
  while (!![]) {
    try {
      var _0x3f4bd9 =
        parseInt(_0x33be65(0xc0)) / 0x1 +
        parseInt(_0x33be65(0xca)) / 0x2 +
        parseInt(_0x33be65(0xc5)) / 0x3 +
        parseInt(_0x33be65(0xc4)) / 0x4 +
        (-parseInt(_0x33be65(0xc9)) / 0x5) * (parseInt(_0x33be65(0xc7)) / 0x6) +
        (parseInt(_0x33be65(0xc6)) / 0x7) * (-parseInt(_0x33be65(0xc2)) / 0x8) +
        (parseInt(_0x33be65(0xc8)) / 0x9) * (parseInt(_0x33be65(0xc1)) / 0xa);
      if (_0x3f4bd9 === _0x514b6d) break;
      else _0x2b409b["push"](_0x2b409b["shift"]());
    } catch (_0x392327) {
      _0x2b409b["push"](_0x2b409b["shift"]());
    }
  }
})(_0x5af2, 0x90169);
class ErrorHandler extends Error {
  constructor(_0x1e6841, _0x4d51bd) {
    var _0x46f3f7 = _0x4ea7;
    super(_0x1e6841),
      (this[_0x46f3f7(0xc3)] = _0x4d51bd),
      Error["captureStackTrace"](this, this["constructor"]);
  }
}
module[_0x57d100(0xcb)] = ErrorHandler;
